// Interface for playable games
public interface Playable {
    void play(); // Method to start playing the game
}
