public abstract class Weapon {
    protected String weaponName;

    public Weapon(String weaponName) {
        this.weaponName = weaponName;
    }

    public abstract void equip(); // Abstract method for equipping
    public abstract int getDamage(); // Abstract method to get weapon damage
}
